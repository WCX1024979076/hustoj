ace.define("ace/snippets/csound_score",[], function(require, exports, module) {
"use strict";

exports.snippetText = "";
exports.scope = "csound_score";

});
                (function() {
                    ace.require(["ace/snippets/csound_score"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            