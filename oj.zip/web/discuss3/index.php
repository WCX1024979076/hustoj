<?php
  header("Location:../");
?>
